package proyectojuego.cadejocurse.Model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author fegem
 */
public class MatrizLaberinto {
    
    //Priv tipo, [fila][columna], llamada laberinto. No se sabe su tamaño aun
    private int [][] laberinto; //Declaracion/Referencia de un arreglo
    
    
    public  MatrizLaberinto(){
        
        
            //Dentro del constructor! esto porque sigue el principio de encapsulamiento y mantiene el codigo ordenado. Ademas permite usarla facilmente
            
        //nombre  = new tipo [fila][columna]   
        laberinto = new int [][]{ //Instancia del arreglo. Al instanciar se ocupa un espacio de memoria
            
            
            //En vez de decirle su tamaño la llenamos directamente
            
            //Muro= 1.  Camino= 0
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1},
            {1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1},
            {1,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,1,1,1,1,1},
            {1,0,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1},
            {1,0,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1},
            {1,0,0,1,0,0,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1},
            {1,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1},
            {1,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1},
            {1,1,1,1,0,0,1,1,1,1,0,0,1,0,0,1,1,1,1,1,1,1},
            {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
            {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
            {1,0,0,1,1,1,1,1,1,1,0,0,1,1,1,1,0,0,1,0,0,1},
            {1,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1},
            {1,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1},
            {1,1,1,1,1,1,1,0,0,1,1,1,1,0,0,1,0,0,1,1,1,1},
            {1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1},
            {1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1},
            {1,0,0,1,1,1,1,0,0,1,0,0,1,1,1,1,0,0,1,0,0,1},
            {1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,1}, //Aqui la meta al inicio
            {1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,1}, //Aqui la meta al inicio
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            
        }; //Cierre constructor
        
        
    } //cierre metodo

    public int[][] getLaberinto() {
        return laberinto;
    }

    public void setLaberinto(int[][] laberinto) {
        this.laberinto = laberinto;
    }
    
    
    
    
    
} //Cierre clase
