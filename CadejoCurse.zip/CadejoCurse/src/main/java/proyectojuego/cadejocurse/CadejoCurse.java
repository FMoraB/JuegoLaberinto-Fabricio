/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package proyectojuego.cadejocurse;

import proyectojuego.cadejocurse.Controller.ControladorPrincipal;

/**
 *
 * @author fegem
 */
public class CadejoCurse {

    public static void main(String[] args) {
        new ControladorPrincipal();
        
        
        
        //Esto es para probar la matriz
        int matrizPrueba [][] = {{0,0,0},{0,0,0}};
        
        System.out.println(matrizPrueba.length);
        
    }
}
