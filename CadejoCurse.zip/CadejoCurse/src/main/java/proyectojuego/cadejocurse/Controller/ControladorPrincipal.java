/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectojuego.cadejocurse.Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import proyectojuego.cadejocurse.View.GUIHistoria;
import proyectojuego.cadejocurse.View.GUIInstrucciones;
import proyectojuego.cadejocurse.View.GUIJuego;
import proyectojuego.cadejocurse.View.GUILaberinto;

/**
 *
 * @author fegem
 */
public class ControladorPrincipal implements ActionListener{

    //Comunica controlador con GUI para que este sepa quien se encarga de los eventos generados
    private GUIJuego guiJuego;
    
    private GUIInstrucciones guiInstrucciones;
    private GUIHistoria guiHistoria;
    private GUILaberinto guiLaberinto;
    

    
    public ControladorPrincipal() {
        //Referencia de GUIJuego
        guiJuego= new GUIJuego(this);
        guiJuego.setVisible(true);
        
        guiInstrucciones= new GUIInstrucciones();
        guiInstrucciones.escuchar(this);
        
        guiHistoria= new GUIHistoria();
        guiHistoria.escuchar(this);
        
        guiLaberinto= new GUILaberinto();
        guiLaberinto.escuchar(this);
       // guiLaberinto.setVisible(true);
        
        
        
        
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
     //Añadir la accion de cada boton
     switch(e.getActionCommand()){
         case "instrucciones":
             guiJuego.setVisible(false);
             guiInstrucciones.setVisible(true);
             break;
             
             case "salir":
             System.exit(0);
             break;
             
             case "historia":
             guiJuego.setVisible(false);
             guiHistoria.setVisible(true);
             
             break;
             
             case "jugar":
             guiJuego.setVisible(false);
             guiLaberinto.setVisible(true);
             break;
             
             case "salirInstruccion":
             guiInstrucciones.setVisible(false);
             guiJuego.setVisible(true);
             break;
             
             case "salirHistoria":
             guiHistoria.setVisible(false);
             guiJuego.setVisible(true);
             break;
             
             case "salirLaberinto":
             guiLaberinto.setVisible(false);
             guiJuego.setVisible(true);
             break;
             
    }
    
}
}//Cierre class
